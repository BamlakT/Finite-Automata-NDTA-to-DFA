README.Txt

                                                                                  Word sentences generator
SET UP NEEDED
- Download a C engine such as Vscode and Clion

HOW TO RUN THE PROGRAM
-Open the file
-Run the program on your C engine, play button in the top right
-A menu will appear and ask you what do you want
-When you have made your choice, enter a number beween 1 & 4


MADE WITH
- The C language and github

AUTORS
Bamlak tadele gurara
Axel aouizerate
Sami boualami 
