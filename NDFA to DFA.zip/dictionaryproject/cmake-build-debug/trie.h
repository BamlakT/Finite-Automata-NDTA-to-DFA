//
// Created by hp on 29-Oct-22.
//

#ifndef DICTIONARYPROJECT_TRIE_H
#define DICTIONARYPROJECT_TRIE_H
/*
#include "LLD.h"


typedef struct trie_cell te_cell, *Trie_cell;
// Trie node
typedef struct Trienode
{
   // node_list * trielist;
    Trie_cell head;
    // isEndOfWord is true if the node
    // represents end of a word
    int isEndOfWord;
}TrieNode;
struct trie_cell
{
    char value;
    TrieNode *child;
    struct trie_cell *next;
};

//typedef struct trie_cell te_cell, *Trie_cell;
TrieNode *createtrienode();
Trie_cell createTrieCell(char);
TrieNode * insertrie(TrieNode ** , p_cell ,int );
TrieNode * insertriefromlist(TrieNode * , t_ht_list);
void displaytrieList(TrieNode);*/
#endif //DICTIONARYPROJECT_TRIE_H
